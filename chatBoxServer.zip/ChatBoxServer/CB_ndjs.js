var wsUri="ws://localhost:3000";
// var wsUri="https://de61912207f6.ngrok.io/";
var output;;
var send_data_JSON, send_data;
var saved_userID;

function init(user_arr)
{
    output = document.getElementById("output");
    if(user_arr[0]==false){
        // console.log(false);
        startWebSocket(user_arr[1]);
    }else if(user_arr[0]==true){
        // console.log(true+user_arr);
        ChatingtWebSocket(user_arr[1]);
    }
}


function startWebSocket(userID)
{
    websocket = new WebSocket(wsUri);
    send_data_JSON={
        prefix:"id_cert",
        id:userID,
    };
    saved_userID=userID;
    send_data=JSON.stringify(send_data_JSON)
    websocket.onopen = function() { onOpen(send_data) };
    websocket.onmessage = function(e) { 
        var his_msg=e.data;
        PrintOnScreem(his_msg);
    };
}


// 自動關閉連線
// var autoCloseConnection_10sec=setInterval(sendCloseSignal,10000);
// let a=0;
// function sendCloseSignal(){
//     a+=10;
//     // websocket = new WebSocket(wsUri);
//     send_data_JSON={
//         id:saved_userID,
//         prefix:"other",
//         message:a,
//     };
//     console.log(send_data_JSON);
//     websocket.send(send_data_JSON)
//     websocket.close();
// }



function ChatingtWebSocket(msg)
{
    // websocket = new WebSocket(wsUri);
    send_data_JSON={
        id:saved_userID,
        prefix:"msg",
        message:msg,
    };
    send_data=JSON.stringify(send_data_JSON);
    console.log(send_data);

    doSend(send_data);
    // websocket.onopen = function() { onOpen(send_data) };

    websocket.onmessage = function(e) { 
        console.log(e.data);
        msgRecevieFromServer(e.data);
        // onMessage(e);
    };
    websocket.onclose = function(evt) { onClose(evt) };
    // websocket.onerror = function(evt) { onError(evt) };
}



function onOpen(send_data)
{
    // writeToScreen("CONNECTED");
    doSend(send_data);
}

function onClose(evt)
{
    // writeToScreen("DISCONNECTED");
}

function onMessage(evt)
{
    // writeToScreen('<span style="color: blue;">RESPONSE: ' + evt.data+'</span>');
    // websocket.close();
}

// function onError(evt)
// {
    // writeToScreen('<span style="color: red;">ERROR:</span> ' + evt.data);
// }

function doSend(message)
{
    // writeToScreen("SENT: " + message);
    websocket.send(message);
}

function writeToScreen(message)
{
    var pre = document.createElement("p");
    pre.style.wordWrap = "break-word";
    pre.innerHTML = message;
    output.appendChild(pre);
}
