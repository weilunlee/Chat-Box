//裝 express 和 ws
const express=require('express');
const SocketServer=require('ws').Server;

//裝fs
const fs=require('fs');
var msg_parsed_JSON;
// var return_his_data;

//建buffer (不用建buffer)
// const buf=new Buffer.from('string', 'utf8');
// 用string串接JSON
var SAVING_DATA="";
var txt_DB="";  

// 連PORT
const PORT=3000;
const server=express().listen(PORT, function(){
    console.log(`Listening on ${PORT}`);
});
// 其他變數
// var player_info;
var his_data,send_data;
var bot_reply_JSON;


// 定義JSON
server_data_JSON={
    prefix:"sending_signal",
    id:"server",
    message:0,
    emot:10,
};
send_data_JSON={
    prefix:"msg",
    id:"bot",
    message:"",
    result:"",
    emot:10,
};



const wss=new SocketServer({server});

// 連結client!!!!!!
wss.on('connection', ws=>{            
    // ??能做甚麼??

    console.log('client connect');
    ws.on('message', e=>{
        // 定義JSON
        server_data_JSON.prefix="sending_signal";
        server_data_JSON.message="";

        console.log("ready to send")
        // 延遲回覆
        var _rand;
        msg_parsed_JSON=JSON.parse(e);
        console.log("e="+e);
        var userID=msg_parsed_JSON.id;
        txt_DB=`${userID}_historical_data.txt`;
        // server_data_JSON.emot=msg_parsed_JSON.emot;
        // 檢測 e 為 ID 還是 訊息    
        if(msg_parsed_JSON.prefix=="id_cert"){                      //ID
            openNewFile();                                          //建檔
            his_data=reading_File(txt_DB).toString('utf8'); 
            console.log("his data:"+his_data);
            ws.send(his_data);
            server_e=JSON.stringify(server_data_JSON);
            ws.send(server_e);

            // 加入問候
            // his_data=concerningMSGProcessing(his_data);
            server_e_g=JSON.stringify(server_data_JSON);
            server_data_JSON.message=1;
            server_e_a=JSON.stringify(server_data_JSON);


            _rand=Math.random()*3+3;
            send_data_JSON_g=input_Proccessing(server_e_g);
            send_data_JSON_a=input_Proccessing(server_e_a);
            send_data_JSON_g.message=userID+" "+send_data_JSON_g.message;
            send_data_g=JSON.stringify(send_data_JSON_g);
            send_data_a=JSON.stringify(send_data_JSON_a);
            setTimeout(function(){
                ws.send(send_data_g);
                SAVING_DATA+=send_data_g+"/%split_here%/";
                console.log("in timer ready to send back history data"+send_data);
                setTimeout(function(){
                    ws.send(send_data_a);
                    SAVING_DATA+=send_data_a+"/%split_here%/";
                    console.log("in timer ready to send back history data"+send_data);
                },500);
                setTimeout(function(){
                    send_data_JSON.message="要不要玩遊戲?";   
                    let send_data_game=JSON.stringify(send_data_JSON);            
                    ws.send(send_data_game);          
                    SAVING_DATA+=send_data_game+"/%split_here%/";
                },1000);
                
            },1000*_rand);
            console.log(SAVING_DATA);
        }else if(msg_parsed_JSON.prefix=="msg"){                    //訊息
            console.log("msg");
            console.log("input msg:"+msg_parsed_JSON.message);
            ws.send(e);                                   //傳送user+bot message
            SAVING_DATA+=e+"/%split_here%/";
            bot_reply_JSON=input_Proccessing(e);                                    //處理全部回應用函數

            ws.send(JSON.stringify(server_data_JSON));                                   //傳送server回復中
            console.log("已送出server訊號");
            _rand=Math.random()*2+1;
            // var timer1=setTimeout(function(){
                // console.log(_rand);
            // },1000*_rand);
            // clearTimeout(timer1);
            setTimeout(function(){
                console.log("in timer ready to send back bot reply");
                 ws.send(JSON.stringify(bot_reply_JSON));                                   //傳送user+bot message
                SAVING_DATA+=JSON.stringify(bot_reply_JSON)+"/%split_here%/";
            },1000*_rand+2);

        }else if(msg_parsed_JSON.prefix=="result"){
            if(msg_parsed_JSON.result=="win"){
                bot_reply_JSON.message="你贏了啦";
                ws.send(JSON.stringify(bot_reply_JSON));                                   //傳送user+bot message
                SAVING_DATA+=JSON.stringify(bot_reply_JSON)+"/%split_here%/";
                bot_reply_JSON=input_Proccessing(e);
                ws.send(JSON.stringify(bot_reply_JSON));                                   //傳送user+bot message
                SAVING_DATA+=JSON.stringify(bot_reply_JSON)+"/%split_here%/";
            }
        }

        // clearTimeout(timer);
        console.log("timer is clear, this iteration ends");
    });
    
    ws.on('close', function(){
        console.log("SAVING DATA:"+SAVING_DATA);
        processing_File(txt_DB, SAVING_DATA);
        // console.log(SAVING_DATA);
        console.log('disconnect');
        SAVING_DATA="";
        send_data="";
    });
});








// 處理全部回應用函數
function input_Proccessing(msg_e){
    console.log("msg_e:"+msg_e);
    var bot_reply_JSON;
    //處理字串 
    bot_reply_JSON=JSON.parse(msg_e);                                   //初始化msg_e(傳進e_string，將string解析為新JSON)
    // 分類prefix=msg
    if(bot_reply_JSON.prefix=="msg"){
        bot_reply_JSON.id="bot";
        bot_reply_JSON.message=input_cleaning(bot_reply_JSON.message);                                //清理文字
        // console.log("cleaned message:"+bot_reply_JSON.message);
        //回應
        // bot_reply_JSON.message=replyStr_Summary(bot_reply_JSON);
        replyStr_Summary(bot_reply_JSON);
        console.log("bot replying msg:"+bot_reply_JSON.message);
        return bot_reply_JSON;
    }
    // 分類prefix=time interval
    else if(bot_reply_JSON.prefix=="sending_signal"){
        bot_reply_JSON.prefix="msg";
        bot_reply_JSON.id="bot";
        //回應
        replyStr_Summary(bot_reply_JSON);
        console.log("bot replying msg:"+bot_reply_JSON.message);
        return bot_reply_JSON;
    }else if(bot_reply_JSON.prefix=="result"){
        bot_reply_JSON.prefix="msg";
        bot_reply_JSON.id="bot";
        //回應
        if(bot_reply_JSON.result=="win"){
            // bot_reply_JSON.message=replyStr_Summary(bot_reply_JSON);
            replyStr_Summary(bot_reply_JSON);
            console.log("bot replying msg:"+bot_reply_JSON.message);
            return bot_reply_JSON;
        }
    }
}





// 處理輸入字元
function input_cleaning(msg){
    // console.log(msg);
    var lower_case_str=msg.toLowerCase();    //  變小寫
    // 去標點符號
    var arr_punc=['。','！','!', '"', '#', '$', '%', '&', '\'', '(', ')', '*',
        '+', ', ', '-', '.', '/', ':', ';', '<', '=', '>',    
        '?', '@', '[', '\\', ']', '^', '_', '`', '{', '|',    
        '}', '~', '；', '﹔', '︰', '﹕', '：', '，', '﹐', '、',    
        '．', '﹒', '˙', '·', '。', '？', '！', '～', '‥', '‧',    
        '′', '〃', '〝', '〞', '‵', '‘', '’', '『', '』', '「',    
        '」', '“', '”', '…', '❞', '❝', '﹁', '﹂', '﹃', '﹄'];

    let str1="["+arr_punc.join('')+"]";
    lower_case_str=lower_case_str.replace(new RegExp(str1,'g'),'');

    // lower_case_str=lower_case_str.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"");

    let arr_aha=["啊","阿","哇","嗎","嘛","了","呢","欸","哈","啦"];
    // 去語助詞
    let str2="["+arr_aha.join('')+"]";
    lower_case_str=lower_case_str.replace(new RegExp(str2,'g'),'');
    return lower_case_str;
}



// 處理輸入與回應
function replyStr_Summary(msg){
    let bot_emotion=emotion_ident(msg.emot);


    var reply_for_nothing_hap=["請問有什麼需要幫忙的嗎?´･ᴗ･`","我能幫你做什麼呢?","今天有什麼事嗎~","嗨~你好啊~(´･ω･`)"];
    var reply_for_nothing_nor=["要幹嘛?","找我做什麼?","今天衝啥?","有事嗎?"];
    var reply_for_nothing_ang=["...","我不想幫你","沒事我走了"];
    var user_greeting_hap=["HI~~","哈囉","你好啊","嗨~你好啊~(´･ω･`)"];
    var user_greeting_nor=["嗨","是你啊","...嗯","來了就來了"];
    var user_greeting_ang=["你還來啊","還敢來?","膽子不小阿"];

    if(bot_emotion=="happy"){
        if(msg.message==0){
            msg.message=user_greeting_hap[Math.round(Math.random()*(user_greeting_hap.length-1))];            
        }
        if(msg.message==1){
            msg.message=reply_for_nothing_hap[Math.round(Math.random()*(reply_for_nothing_hap.length-1))];            
        }
    }else if(bot_emotion=="normal"){
        if(msg.message==0){
            msg.message=user_greeting_nor[Math.round(Math.random()*(user_greeting_nor.length-1))];            
            return;
        }
        if(msg.message==1){
            msg.message=reply_for_nothing_nor[Math.round(Math.random()*(reply_for_nothing_nor.length-1))];            
            return;
        }
    }else if(bot_emotion=="angry"){
        if(msg.message==0){
            msg.message=user_greeting_ang[Math.round(Math.random()*(user_greeting_ang.length-1))];            
            return;
        }
        if(msg.message==1){
            msg.message=reply_for_nothing_ang[Math.round(Math.random()*(reply_for_nothing_ang.length-1))];            
            return;
        }
    }

    var play_or_not="";
    var hi=["hi","hello","你好", "嗨","哈囉","哈摟","哈搂","Good morning","Morning", "Evening", "Good Evening", "你好阿", "早", "早安","你好挖","你好啊","你好哇"];
    var reply_hi=["你好", "嗨","哈囉","早","早安"];
    var who_are_you=["你是誰","你誰","你是啥","誰","Who are you", "What are you","你是甚麼","你是什麼"];
    var reply_who_are_you=["...請別問廢話", "關你屁事", "干卿底事?", "我是你爸", "你不會想知道的", "我是好人，也是壞人", "( ಠ_ಠ )", " | •́ ▾ •̀ |", "٩(●˙▿˙●)۶…⋆ฺ", "(•ิ_•ิ)?"];
    var reply_for_win=["恭喜", "哼", "我明明快就要贏的!!!!","再來一次啦","我不玩了","我不玩了","我不玩了","阿不就好棒棒"];
    console.log(msg);
    play_or_not=msg.message.match(/要/);
    let win_or_not=msg.message.match(/我贏/)
    if(play_or_not=="要"){
        msg.message="好的";
    }

    if(win_or_not=="我贏"){
        msg.emot=msg.emot-1;
        console.log("emotion="+msg.emot);
        for(let i=0;i<hi.length; i++){    
            msg.message=reply_for_win[Math.round(Math.random()*(reply_for_win.length-1))];   
            // return reply_for_win[Math.round(Math.random()*(reply_for_win.length-1))];            
        }        
    }    
    for(let i=0;i<hi.length; i++){    
        if(msg.message==hi[i]){
            msg.message=reply_hi[Math.round(Math.random()*(reply_hi.length-1))];     
            // return reply_hi[Math.round(Math.random()*(reply_hi.length-1))];            
        }        
    }
    for(var i=0;i<who_are_you.length; i++){    
        if(msg.message==who_are_you[i]){
            let num=Math.random()*(reply_who_are_you.length-1);
            console.log(num);
            msg.message=reply_who_are_you[Math.round(num)];            
            // return reply_who_are_you[Math.round(num)];            
        }        
    }
    for(var i=0;i<hi.length; i++){    
        if(msg.message==hi[i]){
            msg.message=reply_hi[Math.round(Math.random()*reply_hi.length)];
            // return reply_hi[Math.round(Math.random()*reply_hi.length)];            
        }        
    }


}

function emotion_ident(emot){
    if(emot>7){
        return "happy";
    }else if(emot<=7 && emot>4){
        return "normal";
    }else if(emot<=7){
        return "angry";
    }


}












// 連結文本資料庫!!!!! 
// 先同步讀檔
function openNewFile(){
    // console.log(Math.round(Math.random()*10));
    fs.open(txt_DB,'a+', function(err, fd){
        if(err) throw 136+"建檔失敗";
    });
}

function reading_File(txt_DB){
    console.log("read successful");
    return (fs.readFileSync(txt_DB));
}



// 非同步寫資料
function processing_File(txt_DB,txt_data){
    // 用buffer來處理!!!!
    fs.open(txt_DB, 'a+', function(err, fd){                 
        if(err) throw 'file open error';
        txt_data=txt_data+"/%split_here%/";
        fs.appendFile(txt_DB, txt_data,'utf8', (err)=>{
            if(err) throw 'append error';
        });
        
        fs.close(fd, (err)=>{
            if(err) throw 'close error';
        });
    });
}