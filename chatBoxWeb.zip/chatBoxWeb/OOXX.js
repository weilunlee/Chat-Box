var all_blocks = document.querySelectorAll("._block");

function OOXX(){
    var OX_boolin = true;
    console.log(all_blocks.length);
    var pOX=document.getElementById("pOX");    
    for(var i=0;i<all_blocks.length;i++){
        all_blocks[i].addEventListener("click", block_press);
        all_blocks[i].innerHTML="";
    }
    
    function O_or_X(){
            var j = 0;
            if(OX_boolin==true){
                ++j;
                OX_boolin=false;
                return "O";
            }else{
                ++j
                OX_boolin=true;
                return "X";
            }
    }
    
    function block_press(){
        var OX=O_or_X();
        this.innerHTML=OX;
        endgame();
    }
    // function opponent(){
        
    //     var blk=new Array();
    //     for(var j=0;j<3;j++){
    //         blk[j]=new Array();
    //     }
    //     if(blk[2][2]==""){
    //         var OX=O_or_X();
    //         this.innerHTML=OX;
    //     }
    //     for(i=0;i<3;i++){
    //         if((blk[i][0]!="")&&(blk[i][1]!="")&&(blk[i][2]!="")){
    //             if((blk[i][0]==blk[i][1])&&(blk[i][1]==blk[i][2])&&(blk[i][0]==blk[i][2])){
    //                 send_playing_result("win");
    //                 console.log("win");
    //             }
    //         }else if((blk[0][i]!="")&&(blk[1][i]!="")&&(blk[2][i]!="")){
    //             if((blk[0][i]==blk[1][i])&&(blk[1][i]==blk[2][i])&&(blk[0][i]==blk[2][i])){
    //                 send_playing_result("win");
    //             }
    //         }else if((blk[0][0]!="")&&(blk[1][1]!="")&&(blk[2][2]!="")){
    //             if((blk[0][0]==blk[1][1])&&(blk[1][1]==blk[2][2])&&(blk[0][0]==blk[2][2])){
    //                 send_playing_result("win");
    //             }
    //         }else if((blk[0][2]!="")&&(blk[1][1]!="")&&(blk[2][0]!="")){
    //             if((blk[0][2]==blk[1][1])&&(blk[1][1]==blk[2][0])&&(blk[0][2]==blk[2][0])){
    //                 send_playing_result("win");
    //             }   
    //         }
    //     }        
    // }
    function endgame(){
        var i=0;
        var k=0; 
        var blk=new Array();
        for(var j=0;j<3;j++){
            blk[j]=new Array();
        }
        for(i=0;i<3;i++){
            // console.log("i="+i);
            for(k=0;k<3;k++){
                // console.log("k="+k);
                blk[i][k]=document.getElementById(`r${i}c${k}`).innerHTML;
                // console.log(typeof blk[i][k]);
            }
        }

        for(i=0;i<3;i++){
            // console.log("here");
            // console.log("blk[i][0]="+blk[i][0])
            if((blk[i][0]!="")&&(blk[i][1]!="")&&(blk[i][2]!="")){
                // console.log(i+"!=");
                if((blk[i][0]==blk[i][1])&&(blk[i][1]==blk[i][2])&&(blk[i][0]==blk[i][2])){
                    send_playing_result("win");
                    console.log("win");
                }
            }else if((blk[0][i]!="")&&(blk[1][i]!="")&&(blk[2][i]!="")){
                if((blk[0][i]==blk[1][i])&&(blk[1][i]==blk[2][i])&&(blk[0][i]==blk[2][i])){
                    send_playing_result("win");
                }
            }else if((blk[0][0]!="")&&(blk[1][1]!="")&&(blk[2][2]!="")){
                if((blk[0][0]==blk[1][1])&&(blk[1][1]==blk[2][2])&&(blk[0][0]==blk[2][2])){
                    send_playing_result("win");
                }
            }else if((blk[0][2]!="")&&(blk[1][1]!="")&&(blk[2][0]!="")){
            if((blk[0][2]==blk[1][1])&&(blk[1][1]==blk[2][0])&&(blk[0][2]==blk[2][0])){
                send_playing_result("win");
            }
        }
        }     
        // console.log("blk[2][2]="+blk[2][2]);
        // console.log("blk[2][1]="+blk[2][1]);
        // console.log(blk[2][1]==blk[2][2]);
        // console.log(typeof blk[2][1]);
        // console.log(typeof blk[2][2]);
    }
}
